const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const pool = mysql.createPool({
  host: process.env.DB_HOST || '127.0.0.1',
  user: process.env.DB_USER || 'root',
  password: (process.env.DB_PASSWORD || process.env.DB_PASS || '').replace(/^['"]|['"]$/g, ''),
  database: process.env.DB_NAME || 'ads_merchants_db',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

function formatMySQLDate(val) {
  if (!val) return new Date().toISOString().slice(0, 19).replace('T', ' ');
  if (val instanceof Date) return val.toISOString().slice(0, 19).replace('T', ' ');
  if (typeof val === 'string') {
    if (val.includes('T')) {
      return val.slice(0, 19).replace('T', ' ');
    }
    return val;
  }
  return new Date().toISOString().slice(0, 19).replace('T', ' ');
}

// Helper for queries
async function query(sql, params) {
  const [rows] = await pool.execute(sql, params);
  return rows;
}

const db = {
  query: query,
  getSettings: async () => {
    const rows = await query('SELECT * FROM settings');
    const settings = {};
    rows.forEach(row => {
      try {
        // Parse JSON for vip_rates if possible
        settings[row.setting_key] = row.setting_key === 'vip_rates' ? JSON.parse(row.setting_value) : row.setting_value;
      } catch (e) {
        settings[row.setting_key] = row.setting_value;
      }
    });
    return settings;
  },
  
  updateSettings: async (newSettings) => {
    for (const [key, value] of Object.entries(newSettings)) {
      const val = typeof value === 'object' ? JSON.stringify(value) : value;
      await query('INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?', [key, val, val]);
    }
    return db.getSettings();
  },

  formatUser: (u) => {
    if (!u) return null;
    return {
      ...u,
      balance: parseFloat(u.balance || 0),
      frozen_balance: parseFloat(u.frozen_balance || 0),
      today_profit: parseFloat(u.today_profit || 0),
      today_tasks_completed: parseInt(u.today_tasks_completed || 0, 10),
      total_tasks_completed: parseInt(u.total_tasks_completed || 0, 10),
      current_set: parseInt(u.current_set || 0, 10),
      custom_order_num: u.custom_order_num ? parseInt(u.custom_order_num, 10) : null,
      custom_deficit_amount: u.custom_deficit_amount !== null && u.custom_deficit_amount !== undefined ? parseFloat(u.custom_deficit_amount) : null,
      custom_product_price: u.custom_product_price !== null && u.custom_product_price !== undefined ? parseFloat(u.custom_product_price) : null
    };
  },

  getUsers: async () => {
    const rows = await query('SELECT * FROM users ORDER BY created_at DESC, id DESC');
    return rows.map(db.formatUser);
  },

  findUserById: async (id) => {
    const rows = await query('SELECT * FROM users WHERE id = ?', [id]);
    return db.formatUser(rows[0]);
  },

  findUserByIdentifier: async (identifier) => {
    if (!identifier) return null;
    const clean = String(identifier).trim().toLowerCase();
    const rows = await query('SELECT * FROM users WHERE LOWER(email) = ? OR LOWER(username) = ? OR (phone != "" AND phone IS NOT NULL AND phone = ?)', [clean, clean, clean]);
    return db.formatUser(rows[0]);
  },

  getNextUserId: async () => {
    try {
      const rows = await query(`
        SELECT id FROM users 
        WHERE id REGEXP '^[0-9]+$' 
        ORDER BY CAST(id AS UNSIGNED) DESC 
        LIMIT 1
      `);
      if (rows && rows.length > 0) {
        const highest = parseInt(rows[0].id, 10);
        if (!isNaN(highest) && highest >= 1000) {
          return String(highest + 1);
        }
      }
    } catch (e) {
      console.error('Error fetching max user id:', e);
    }
    return '1001';
  },

  migrateUserIdsToSequential: async () => {
    try {
      const nonNumericUsers = await query(`
        SELECT id, created_at FROM users 
        WHERE id NOT REGEXP '^[0-9]+$' 
        ORDER BY created_at ASC
      `);
      if (!nonNumericUsers || nonNumericUsers.length === 0) return;

      console.log(`[MIGRATION] Found ${nonNumericUsers.length} legacy user IDs to convert to sequential 1000+ IDs...`);
      
      try { await query('SET FOREIGN_KEY_CHECKS = 0'); } catch (_) {}
      
      for (const u of nonNumericUsers) {
        const nextId = await db.getNextUserId();
        const oldId = u.id;
        
        await query('UPDATE users SET id = ? WHERE id = ?', [nextId, oldId]);
        await query('UPDATE deposits SET user_id = ? WHERE user_id = ?', [nextId, oldId]);
        await query('UPDATE withdrawals SET user_id = ? WHERE user_id = ?', [nextId, oldId]);
        await query('UPDATE tasks SET user_id = ? WHERE user_id = ?', [nextId, oldId]);
        await query('UPDATE kyc_submissions SET user_id = ? WHERE user_id = ?', [nextId, oldId]);
        await query('UPDATE support_tickets SET user_id = ? WHERE user_id = ?', [nextId, oldId]);
        await query('UPDATE notifications SET user_id = ? WHERE user_id = ?', [nextId, oldId]);
        await query('UPDATE chat_messages SET user_id = ? WHERE user_id = ?', [nextId, oldId]);
        
        console.log(`[MIGRATION] Successfully migrated user ${oldId} -> ${nextId}`);
      }
      
      // Clean up legacy placeholder phone numbers
      try {
        await query("UPDATE users SET phone = '' WHERE phone = '0000000000' OR phone REGEXP '^0+$'");
      } catch (_) {}

      try { await query('SET FOREIGN_KEY_CHECKS = 1'); } catch (_) {}
    } catch (err) {
      console.error('[MIGRATION ERROR] Could not migrate legacy user IDs:', err);
      try { await query('SET FOREIGN_KEY_CHECKS = 1'); } catch (_) {}
    }
  },

  createUser: async (userData) => {
    const id = userData.id || (await db.getNextUserId());
    await query(`INSERT INTO users 
      (id, fullname, username, email, phone, gender, password_hash, vip_level, balance, frozen_balance, today_profit, today_tasks_completed, total_tasks_completed, current_set, invite_code, status, created_at) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
      [
        id, userData.fullname || '', userData.username || '', userData.email || '', userData.phone || '', userData.gender || 'Male', userData.password_hash || '', 
        userData.vip_level || 'Bronze', userData.balance || 0, userData.frozen_balance || 0, userData.today_profit || 0, 
        userData.today_tasks_completed || 0, userData.total_tasks_completed || 0, userData.current_set || 0, userData.invite_code || '', 
        userData.status || 'active', formatMySQLDate(userData.created_at || new Date())
      ]);
    return { ...userData, id };
  },

  updateUser: async (id, updates) => {
    const allowed = [
      'fullname', 'username', 'email', 'phone', 'gender', 'password_hash', 
      'vip_level', 'balance', 'frozen_balance', 'today_profit', 
      'today_tasks_completed', 'total_tasks_completed', 'current_set', 
      'invite_code', 'kyc_status', 'kyc_notes', 'status',
      'custom_order_num', 'custom_deficit_amount', 'custom_product_name', 'custom_product_price',
      'country_code', 'country_name', 'last_ip'
    ];
    const filteredUpdates = {};
    for (const key of Object.keys(updates)) {
      if (allowed.includes(key)) {
        filteredUpdates[key] = updates[key];
      }
    }
    const keys = Object.keys(filteredUpdates);
    if (keys.length === 0) return await db.findUserById(id);
    const setClause = keys.map(k => `${k} = ?`).join(', ');
    const values = Object.values(filteredUpdates);
    values.push(id);
    await query(`UPDATE users SET ${setClause} WHERE id = ?`, values);
    return await db.findUserById(id);
  },

  resetUserPassword: async (userId, newPlainPassword) => {
    const hash = bcrypt.hashSync(newPlainPassword, 10);
    await query('UPDATE users SET password_hash = ? WHERE id = ?', [hash, userId]);
    return await db.findUserById(userId);
  },

  getProducts: async () => {
    return await query('SELECT * FROM products');
  },

  getTasks: async (userId) => {
    if (userId) {
      return await query('SELECT * FROM tasks WHERE user_id = ?', [userId]);
    }
    return await query('SELECT * FROM tasks');
  },

  createTask: async (taskData) => {
    await query(`INSERT INTO tasks (id, user_id, product_id, product_name, product_price, commission_rate, commission_earned, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [taskData.id, taskData.user_id, taskData.product_id, taskData.product_name, taskData.product_price, taskData.commission_rate, taskData.commission_earned, taskData.status, formatMySQLDate(taskData.created_at)]);
    return taskData;
  },

  updateTask: async (id, updates) => {
    const allowed = ['product_id', 'product_name', 'product_price', 'commission_rate', 'commission_earned', 'status', 'created_at'];
    const filteredUpdates = {};
    for (const key of Object.keys(updates)) {
      if (allowed.includes(key)) {
        filteredUpdates[key] = key === 'created_at' ? formatMySQLDate(updates[key]) : updates[key];
      }
    }
    const keys = Object.keys(filteredUpdates);
    if (keys.length === 0) return;
    const setClause = keys.map(k => `${k} = ?`).join(', ');
    const values = Object.values(filteredUpdates);
    values.push(id);
    await query(`UPDATE tasks SET ${setClause} WHERE id = ?`, values);
  },

  getDeposits: async (userId) => {
    let sql = `
      SELECT d.*, u.username, u.fullname, u.phone 
      FROM deposits d 
      LEFT JOIN users u ON d.user_id = u.id
    `;
    if (userId) {
      sql += ` WHERE d.user_id = ? ORDER BY d.created_at DESC`;
      return await query(sql, [userId]);
    }
    sql += ` ORDER BY d.created_at DESC`;
    return await query(sql);
  },

  createDeposit: async (depositData) => {
    await query(`INSERT INTO deposits (id, user_id, user_email, amount, method, txid, proof_image, status, admin_notes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [depositData.id, depositData.user_id, depositData.user_email, depositData.amount, depositData.method, depositData.txid, depositData.proof_image, depositData.status || 'pending', depositData.admin_notes || '', formatMySQLDate(depositData.created_at)]);
    return depositData;
  },

  updateDeposit: async (id, updates) => {
    const allowed = ['user_id', 'user_email', 'amount', 'method', 'txid', 'proof_image', 'status', 'admin_notes', 'created_at'];
    const filteredUpdates = {};
    for (const key of Object.keys(updates)) {
      if (allowed.includes(key)) {
        filteredUpdates[key] = key === 'created_at' ? formatMySQLDate(updates[key]) : updates[key];
      }
    }
    const keys = Object.keys(filteredUpdates);
    if (keys.length === 0) return;
    const setClause = keys.map(k => `${k} = ?`).join(', ');
    const values = Object.values(filteredUpdates);
    values.push(id);
    await query(`UPDATE deposits SET ${setClause} WHERE id = ?`, values);
  },

  getWithdrawals: async (userId = null) => {
    let sql = `
      SELECT 
        w.*, 
        w.bank_name as method,
        w.account_number as wallet_address,
        u.fullname, 
        u.username
      FROM withdrawals w 
      LEFT JOIN users u ON w.user_id = u.id
    `;
    if (userId) {
      sql += ` WHERE w.user_id = ? ORDER BY w.created_at DESC`;
      return await query(sql, [userId]);
    }
    sql += ` ORDER BY w.created_at DESC`;
    return await query(sql);
  },

  createWithdrawal: async (withdrawalData) => {
    const id = withdrawalData.id || ('wth_' + Date.now());
    const bankName = withdrawalData.bank_name || withdrawalData.method || 'USDT';
    const accountName = withdrawalData.account_name || withdrawalData.account_holder || withdrawalData.user_name || 'Merchant';
    const accountNumber = withdrawalData.account_number || withdrawalData.wallet_address || withdrawalData.iban || '';

    await query(`INSERT INTO withdrawals (id, user_id, user_email, amount, bank_name, account_name, account_number, status, admin_notes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [id, withdrawalData.user_id, withdrawalData.user_email || '', withdrawalData.amount, bankName, accountName, accountNumber, withdrawalData.status || 'pending', withdrawalData.admin_notes || '', formatMySQLDate(withdrawalData.created_at || new Date())]);
    return withdrawalData;
  },

  updateWithdrawal: async (id, updates) => {
    const allowed = ['user_id', 'user_email', 'amount', 'bank_name', 'account_name', 'account_number', 'status', 'admin_notes', 'created_at'];
    const filteredUpdates = {};
    for (const key of Object.keys(updates)) {
      if (allowed.includes(key)) {
        filteredUpdates[key] = key === 'created_at' ? formatMySQLDate(updates[key]) : updates[key];
      }
    }
    const keys = Object.keys(filteredUpdates);
    if (keys.length === 0) return;
    const setClause = keys.map(k => `${k} = ?`).join(', ');
    const values = Object.values(filteredUpdates);
    values.push(id);
    await query(`UPDATE withdrawals SET ${setClause} WHERE id = ?`, values);
  },

  // KYC Helpers
  getKycSubmissions: async (userId) => {
    let sql = `
      SELECT k.*, u.username, u.fullname, u.phone 
      FROM kyc_submissions k 
      LEFT JOIN users u ON k.user_id = u.id
    `;
    if (userId) {
      sql += ` WHERE k.user_id = ? ORDER BY k.created_at DESC`;
      return await query(sql, [userId]);
    }
    sql += ` ORDER BY k.created_at DESC`;
    return await query(sql);
  },

  createKycSubmission: async (kycData) => {
    await query(`INSERT INTO kyc_submissions (id, user_id, user_email, name, front_id_image, back_id_image, signature_image, investment_amount, status, rejection_reason, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [kycData.id, kycData.user_id, kycData.user_email, kycData.name, kycData.front_id_image, kycData.back_id_image, kycData.signature_image, kycData.investment_amount, kycData.status || 'pending', kycData.rejection_reason || '', formatMySQLDate(kycData.created_at)]);
    return kycData;
  },

  updateKycSubmission: async (id, updates) => {
    const allowed = ['user_id', 'user_email', 'name', 'front_id_image', 'back_id_image', 'signature_image', 'investment_amount', 'status', 'rejection_reason', 'created_at'];
    const filteredUpdates = {};
    for (const key of Object.keys(updates)) {
      if (allowed.includes(key)) {
        filteredUpdates[key] = key === 'created_at' ? formatMySQLDate(updates[key]) : updates[key];
      }
    }
    const keys = Object.keys(filteredUpdates);
    if (keys.length === 0) return;
    const setClause = keys.map(k => `${k} = ?`).join(', ');
    const values = Object.values(filteredUpdates);
    values.push(id);
    await query(`UPDATE kyc_submissions SET ${setClause} WHERE id = ?`, values);
  },

  // Support Tickets
  getSupportTickets: async (userId) => {
    if (userId) return await query('SELECT * FROM support_tickets WHERE user_id = ? ORDER BY created_at DESC', [userId]);
    return await query('SELECT * FROM support_tickets ORDER BY created_at DESC');
  },

  createSupportTicket: async (ticketData) => {
    await query(`INSERT INTO support_tickets (id, user_id, user_email, user_name, subject, message, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [ticketData.id, ticketData.user_id, ticketData.user_email, ticketData.user_name, ticketData.subject, ticketData.message, ticketData.status || 'open', formatMySQLDate(ticketData.created_at)]);
    return ticketData;
  },

  updateSupportTicket: async (id, updates) => {
    const allowed = ['user_id', 'user_email', 'user_name', 'subject', 'message', 'admin_reply', 'status', 'created_at', 'replied_at'];
    const filteredUpdates = {};
    for (const key of Object.keys(updates)) {
      if (allowed.includes(key)) {
        filteredUpdates[key] = (key === 'created_at' || key === 'replied_at') ? formatMySQLDate(updates[key]) : updates[key];
      }
    }
    const keys = Object.keys(filteredUpdates);
    if (keys.length === 0) return;
    const setClause = keys.map(k => `${k} = ?`).join(', ');
    const values = Object.values(filteredUpdates);
    values.push(id);
    await query(`UPDATE support_tickets SET ${setClause} WHERE id = ?`, values);
  },

  // Notifications
  ensureNotificationsTable: async () => {
    await query(`CREATE TABLE IF NOT EXISTS notifications (
      id VARCHAR(100) PRIMARY KEY,
      user_id VARCHAR(50) NOT NULL,
      title VARCHAR(255),
      message TEXT,
      type VARCHAR(50) DEFAULT 'info',
      is_read BOOLEAN DEFAULT FALSE,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      INDEX (user_id),
      INDEX (created_at)
    )`);
  },

  getNotifications: async (userId, unreadOnly = false) => {
    await db.ensureNotificationsTable();
    let sql = 'SELECT * FROM notifications';
    let params = [];
    let conditions = [];
    
    if (userId) {
      conditions.push('user_id = ?');
      params.push(userId);
    }
    if (unreadOnly) {
      conditions.push('is_read = FALSE');
    }
    
    if (conditions.length > 0) {
      sql += ' WHERE ' + conditions.join(' AND ');
    }
    sql += ' ORDER BY created_at DESC';
    
    return await query(sql, params);
  },

  createNotification: async (notifData) => {
    await db.ensureNotificationsTable();
    const id = 'notif_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
    await query(`INSERT INTO notifications (id, user_id, title, message, type, is_read, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [id, notifData.user_id, notifData.title, notifData.message, notifData.type || 'info', false, formatMySQLDate(notifData.created_at)]);
    return { id, ...notifData };
  },

  markNotificationsRead: async (userId) => {
    await db.ensureNotificationsTable();
    await query('UPDATE notifications SET is_read = TRUE WHERE user_id = ?', [userId]);
    return true;
  },

  // Chat Messages
  ensureChatMessagesTable: async () => {
    await query(`CREATE TABLE IF NOT EXISTS chat_messages (
      id VARCHAR(100) PRIMARY KEY,
      user_id VARCHAR(50) NOT NULL,
      user_name VARCHAR(255),
      user_email VARCHAR(255),
      sender VARCHAR(20) DEFAULT 'user',
      message_text TEXT,
      read_by_admin BOOLEAN DEFAULT FALSE,
      read_by_user BOOLEAN DEFAULT FALSE,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      INDEX (user_id),
      INDEX (created_at)
    )`);
  },

  cleanupExpiredChatMessages: async () => {
    await db.ensureChatMessagesTable();
    try {
      await query(`DELETE FROM chat_messages WHERE created_at < NOW() - INTERVAL 10 MINUTE`);
    } catch (_) {}
  },

  getChatMessages: async (userId) => {
    await db.cleanupExpiredChatMessages();
    return await query(`
      SELECT 
        id, 
        user_id, 
        user_name, 
        user_email, 
        sender, 
        message_text, 
        message_text AS text, 
        read_by_admin, 
        read_by_user, 
        created_at 
      FROM chat_messages 
      WHERE user_id = ? AND created_at >= NOW() - INTERVAL 10 MINUTE
      ORDER BY created_at ASC
    `, [userId]);
  },

  createChatMessage: async ({ userId, sender, text, userName, userEmail, ipAddress, countryCode, countryName }) => {
    await db.cleanupExpiredChatMessages();
    const id = 'msg_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
    const readByAdmin = sender === 'admin';
    const readByUser = sender === 'user';
    const cleanText = (text || '').trim();
    await query(`INSERT INTO chat_messages (id, user_id, user_name, user_email, sender, message_text, read_by_admin, read_by_user, ip_address, country_code, country_name, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
      [id, userId, userName || 'User', userEmail || '', sender || 'user', cleanText, readByAdmin, readByUser, ipAddress || null, countryCode || null, countryName || null]);
    return { id, user_id: userId, sender, text: cleanText, message_text: cleanText, ip_address: ipAddress, country_code: countryCode, country_name: countryName, created_at: new Date().toISOString() };
  },

  getChatConversations: async () => {
    await db.cleanupExpiredChatMessages();
    const sql = `
      SELECT 
        c.user_id, 
        u.fullname as user_name, 
        u.email as user_email, 
        u.vip_level, 
        u.balance,
        COALESCE(u.country_code, c.country_code, 'PK') as country_code,
        COALESCE(u.country_name, c.country_name, 'Pakistan') as country_name,
        COALESCE(u.last_ip, c.ip_address, '127.0.0.1') as ip_address,
        c.message_text as last_message, 
        c.created_at as last_message_at, 
        c.sender as last_sender,
        (SELECT COUNT(*) FROM chat_messages WHERE user_id = c.user_id AND sender = 'user' AND read_by_admin = FALSE AND created_at >= NOW() - INTERVAL 10 MINUTE) as unread_admin_count,
        (SELECT COUNT(*) FROM chat_messages WHERE user_id = c.user_id AND sender = 'user' AND read_by_admin = FALSE AND created_at >= NOW() - INTERVAL 10 MINUTE) as unread_count
      FROM chat_messages c
      JOIN users u ON c.user_id = u.id
      WHERE c.created_at = (SELECT MAX(created_at) FROM chat_messages WHERE user_id = c.user_id)
        AND c.created_at >= NOW() - INTERVAL 10 MINUTE
      ORDER BY c.created_at DESC
    `;
    return await query(sql);
  },

  markChatReadByAdmin: async (userId) => {
    await db.ensureChatMessagesTable();
    await query(`UPDATE chat_messages SET read_by_admin = TRUE WHERE user_id = ? AND sender = 'user'`, [userId]);
    return true;
  },

  markChatReadByUser: async (userId) => {
    await db.ensureChatMessagesTable();
    await query(`UPDATE chat_messages SET read_by_user = TRUE WHERE user_id = ? AND sender = 'admin'`, [userId]);
    return true;
  },

  // STAFF & SUB-ADMIN MANAGEMENT
  ensureAdminsTable: async () => {
    await query(`CREATE TABLE IF NOT EXISTS admins (
      id VARCHAR(50) PRIMARY KEY,
      fullname VARCHAR(255) NOT NULL,
      email VARCHAR(255) UNIQUE NOT NULL,
      password_hash VARCHAR(255) NOT NULL,
      role VARCHAR(50) DEFAULT 'sub_admin',
      status VARCHAR(50) DEFAULT 'active',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);
    // Seed default super admin if not present
    await query(`INSERT IGNORE INTO admins (id, fullname, email, password_hash, role, status) VALUES 
      ('adm_super_01', 'Haider Usama (Super Admin)', 'haiderusama707@gmail.com', '$2a$10$rivBQfrtPN44a4B0xCVmbu9y/EuyazJLNC0L433WMnO18yJKTYSfi', 'super_admin', 'active')
    `);
  },

  getAdmins: async () => {
    await db.ensureAdminsTable();
    return await query('SELECT id, fullname, email, role, status, created_at FROM admins ORDER BY created_at DESC');
  },

  findAdminByEmail: async (identifier) => {
    if (!identifier) return null;
    await db.ensureAdminsTable();
    const clean = identifier.trim().toLowerCase();
    const rows = await query('SELECT * FROM admins WHERE LOWER(email) = ? OR LOWER(fullname) = ?', [clean, clean]);
    return rows[0] || null;
  },

  createAdmin: async (adminData) => {
    await db.ensureAdminsTable();
    await query(`INSERT INTO admins (id, fullname, email, password_hash, role, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [adminData.id, adminData.fullname, adminData.email.trim().toLowerCase(), adminData.password_hash, adminData.role || 'sub_admin', adminData.status || 'active', formatMySQLDate(adminData.created_at)]
    );
    return adminData;
  },

  updateAdmin: async (id, updates) => {
    await db.ensureAdminsTable();
    const keys = Object.keys(updates);
    if (keys.length === 0) return null;
    const setClause = keys.map(k => `${k} = ?`).join(', ');
    const values = Object.values(updates);
    values.push(id);
    await query(`UPDATE admins SET ${setClause} WHERE id = ?`, values);
    return true;
  },

  deleteAdmin: async (id) => {
    await db.ensureAdminsTable();
    await query('DELETE FROM admins WHERE id = ?', [id]);
    return true;
  },

  // TASKS & SMART COMMISSION ENGINE
  ensureTasksTable: async () => {
    await query(`CREATE TABLE IF NOT EXISTS tasks (
      id VARCHAR(50) PRIMARY KEY,
      user_id VARCHAR(50) NOT NULL,
      product_id INT,
      product_name VARCHAR(255),
      product_image VARCHAR(255),
      product_price DECIMAL(15,2),
      commission_rate DECIMAL(5,4),
      commission_earned DECIMAL(15,2),
      status VARCHAR(50) DEFAULT 'pending',
      order_num INT DEFAULT 1,
      is_deficit TINYINT(1) DEFAULT 0,
      deficit_amount DECIMAL(15,2) DEFAULT 0.00,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      INDEX(user_id)
    )`);
    try {
      const cols = await query(`SHOW COLUMNS FROM tasks`);
      const colNames = cols.map(c => c.Field.toLowerCase());
      if (!colNames.includes('product_image')) {
        await query(`ALTER TABLE tasks ADD COLUMN product_image VARCHAR(255) DEFAULT NULL`);
      }
      if (!colNames.includes('order_num')) {
        await query(`ALTER TABLE tasks ADD COLUMN order_num INT DEFAULT 1`);
      }
      if (!colNames.includes('is_deficit')) {
        await query(`ALTER TABLE tasks ADD COLUMN is_deficit TINYINT(1) DEFAULT 0`);
      }
      if (!colNames.includes('deficit_amount')) {
        await query(`ALTER TABLE tasks ADD COLUMN deficit_amount DECIMAL(15,2) DEFAULT 0.00`);
      }
    } catch (_) {}
  },

  getTasks: async (userId) => {
    await db.ensureTasksTable();
    const rows = (userId !== undefined && userId !== null)
      ? await query(`SELECT * FROM tasks WHERE user_id = ? ORDER BY created_at DESC`, [userId])
      : await query(`SELECT * FROM tasks ORDER BY created_at DESC`);
    return rows.map(r => ({
      ...r,
      product_price: parseFloat(r.product_price || 0),
      commission_rate: parseFloat(r.commission_rate || 0),
      commission_earned: parseFloat(r.commission_earned || 0),
      commission_amount: parseFloat(r.commission_earned || 0),
      deficit_amount: parseFloat(r.deficit_amount || 0)
    }));
  },

  createTask: async (task) => {
    await db.ensureTasksTable();
    const commEarned = task.commission_earned || task.commission_amount || 0;
    await query(`INSERT INTO tasks (id, user_id, product_name, product_image, product_price, commission_rate, commission_earned, status, order_num, is_deficit, deficit_amount, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        task.id,
        task.user_id,
        task.product_name,
        task.product_image || null,
        task.product_price,
        task.commission_rate,
        commEarned,
        task.status || 'pending',
        task.order_num || 1,
        task.is_deficit ? 1 : 0,
        task.deficit_amount || 0,
        formatMySQLDate(task.created_at || new Date())
      ]
    );
    return task;
  },

  updateTask: async (id, updates) => {
    await db.ensureTasksTable();
    const allowed = ['status', 'commission_earned', 'order_num', 'is_deficit', 'deficit_amount'];
    const keys = Object.keys(updates).filter(k => allowed.includes(k));
    if (keys.length === 0) return true;
    const setClause = keys.map(k => `${k} = ?`).join(', ');
    const values = keys.map(k => updates[k]);
    values.push(id);
    await query(`UPDATE tasks SET ${setClause} WHERE id = ?`, values);
    return true;
  },

  deletePendingTasks: async (userId) => {
    await db.ensureTasksTable();
    await query(`DELETE FROM tasks WHERE user_id = ? AND status = 'pending'`, [userId]);
    return true;
  },

  getProducts: async () => {
    await query(`CREATE TABLE IF NOT EXISTS products (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      price DECIMAL(15,2) NOT NULL,
      image VARCHAR(255)
    )`);
    const rows = await query(`SELECT * FROM products WHERE image NOT LIKE '%icon.png%' AND image NOT LIKE '%logo%'`);
    if (rows.length === 0) {
      const defaultProducts = [
        ['Lifetime 9446 Outdoor Storage Shed, 12x 16 Foot, Desert Sand Black&Brown (2 in set)', 3674.00, 'client/assets/uploads/products/outdoor_shed.jpg'],
        ['Bulk 15000 PCS Foam Glow Sticks with 3 Modes Colorful Flashing, Glow in Dark Party Supplies', 1856.00, 'client/assets/uploads/products/glow_sticks.jpg'],
        ['Sony WH-1000XM5 Wireless Noise-Canceling Over-Ear Headphones, Black', 398.00, 'client/assets/uploads/products/sony_headphones.jpg'],
        ['Apple iPhone 16 Pro Max 256GB - Desert Titanium, 5G Unlocked', 1199.00, 'client/assets/uploads/products/iphone_16.jpg'],
        ['Dyson V15 Detect Cordless Vacuum Cleaner with Laser Dust Detection, Yellow/Iron', 749.99, 'client/assets/uploads/products/dyson_vacuum.jpg'],
        ['Samsung 65-Inch Class OLED 4K S90D Series HDR+ Smart TV with Dolby Atmos', 1597.99, 'client/assets/uploads/products/samsung_tv.jpg'],
        ['KitchenAid Artisan Series 5-Quart Tilt-Head Stand Mixer, Stainless Steel Bowl, Empire Red', 449.95, 'client/assets/uploads/products/kitchenaid_mixer.jpg'],
        ['DeWalt 20V MAX Cordless Drill and Impact Driver Combo Kit, 2-Tool with 2.0Ah Batteries', 229.00, 'client/assets/uploads/products/dewalt_drill.jpg'],
        ['Breville Barista Touch Espresso Machine, Brushed Stainless Steel, Touch Screen', 999.95, 'client/assets/uploads/products/espresso_machine.jpg'],
        ['DJI Mini 4 Pro Fly More Combo Drone with DJI RC 2, 4K HDR Video', 1099.00, 'client/assets/uploads/products/dji_drone.jpg'],
        ['Apple MacBook Air 15-inch Laptop with M3 chip, 16GB Memory, 512GB SSD, Midnight', 1499.00, 'client/assets/uploads/products/macbook_air.jpg'],
        ['Bose Smart Ultra Soundbar with Dolby Atmos and Voice Control, Black Wireless', 899.00, 'client/assets/uploads/products/soundbar.jpg'],
        ['Ninja Foodi 10-in-1 DualZone 2-Basket Air Fryer XL, 10-Qt Capacity', 249.99, 'client/assets/uploads/products/air_fryer.jpg'],
        ['Segway Ninebot KickScooter MAX G2, 22 mph Max Speed, 43 Miles Long Range', 899.99, 'client/assets/uploads/products/scooter.jpg'],
        ['Sony PlayStation 5 Slim Console (PS5 Disc Edition) 1TB SSD with DualSense Controller', 499.99, 'client/assets/uploads/products/ps5_console.jpg'],
        ['Anker SOLIX C1000 Portable Power Station, 1800W Solar Generator, 1056Wh LiFePO4', 649.00, 'client/assets/uploads/products/power_station.jpg'],
        ['Canon EOS R6 Mark II Mirrorless Camera with 24-105mm STM Lens, 24.2 MP, 4K60p', 2399.00, 'client/assets/uploads/products/canon_camera.jpg'],
        ['LG 34-Inch UltraWide Curved Gaming Monitor 144Hz 1ms Nano IPS QHD, G-SYNC', 799.99, 'client/assets/uploads/products/gaming_monitor.jpg'],
        ['EcoFlow Glacier Portable Refrigerator 40L with Integrated Ice Maker Dual Zone', 849.00, 'client/assets/uploads/products/cooler.jpg'],
        ['Coleman WeatherMaster 10-Person Outdoor Camping Tent with Screen Room', 329.99, 'client/assets/uploads/products/camping_tent.jpg']
      ];
      await query(`DELETE FROM products WHERE image LIKE '%icon.png%' OR image LIKE '%logo%'`);
      for (const [name, price, img] of defaultProducts) {
        await query(`INSERT INTO products (name, price, image) VALUES (?, ?, ?)`, [name, price, img]);
      }
      return await query(`SELECT * FROM products`);
    }
    return rows;
  }
};

module.exports = db;
